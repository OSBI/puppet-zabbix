package main;

# %LICENSE%

use strict;
use warnings;

use base 'Exporter';

use constant DBG  => 4;
use constant INFO => 3;
use constant WARN => 2;
use constant ERR  => 1;

our @EXPORT_OK = ('DBG', 'INFO', 'WARN', 'ERR');
our %EXPORT_TAGS = ( stooges => [ 'DBG', 'INFO', 'WARN', 'ERR' ] );

1;
__END__
