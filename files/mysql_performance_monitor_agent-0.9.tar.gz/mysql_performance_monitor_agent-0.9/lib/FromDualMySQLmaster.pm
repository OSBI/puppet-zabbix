package FromDualMySQLmaster;

#
# Copyright (C) 2010, 2011, 2012 FromDual GmbH
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/>.
#

use strict;
use warnings;

use FromDualMySQLagent ':stooges';
use sendData;

sub getMasterStatus
{
  my $dbh = shift;
  my $status_ref = shift;

  if ( $main::gParameter{'Debug'} >= INFO ) { &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, INFO, '    ' . (caller(0))[3]); }

  # +----------------+----------+--------------+------------------+
  # | File           | Position | Binlog_Do_DB | Binlog_Ignore_DB |
  # +----------------+----------+--------------+------------------+
  # | bin-log.000001 |     1676 |              |                  |
  # +----------------+----------+--------------+------------------+

  $$status_ref{'Binlog_position'} = '0';
  $$status_ref{'Binlog_file'} = '';
  $$status_ref{'Binlog_number'} = '0';

  my $sql = 'SHOW MASTER STATUS';
  my $sth = $dbh->prepare($sql);
  if ( $sth->execute() )
  {
    if ( my $ref = $sth->fetchrow_hashref() )
    {
      $$status_ref{'Binlog_position'} = $ref->{'Position'};
      $$status_ref{'Binlog_file'} = $ref->{'File'};
      if ( $$status_ref{'Binlog_file'} =~ m/^.*\.(\d{4,6})$/ )
      {
        $$status_ref{'Binlog_number'} = $1+0;
      }
    }
    $sth->finish();
  }

  if ( $main::gParameter{'Debug'} == DBG )
  {
    &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, '    Master status:');
    foreach my $key ( keys %$status_ref )
    {
      &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, "      key: $key, value: $$status_ref{$key}");
    }
  }
}

sub getBinaryLogs
{
  my $dbh = shift;
  my $status_ref = shift;

  if ( $main::gParameter{'Debug'} >= INFO ) { &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, INFO, '    ' . (caller(0))[3]); }

  # +----------------+-----------+
  # | Log_name       | File_size |
  # +----------------+-----------+
  # | bin-log.000001 |      1717 |
  # | bin-log.000002 |       107 |
  # +----------------+-----------+

  $$status_ref{'Binlog_count'} = '0';
  $$status_ref{'Binlog_total_size'} = '0';

  my $sql = 'SHOW BINARY LOGS';
  my $sth = $dbh->prepare($sql);
  if ( $sth->execute() )
  {
    while ( my $ref = $sth->fetchrow_hashref() )
    {
      $$status_ref{'Binlog_count'} += 1;
      $$status_ref{'Binlog_total_size'} += $ref->{'File_size'};
    }
    $sth->finish();
  }

  if ( $main::gParameter{'Debug'} == DBG )
  {
    &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, '    Master status:');
    foreach my $key ( keys %$status_ref )
    {
      &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, "      key: $key, value: $$status_ref{$key}");
    }
  }
}

sub getSlaveCount
{
  my $dbh = shift;
  my $status_ref = shift;

  if ( $main::gParameter{'Debug'} >= INFO ) { &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, INFO, '    ' . (caller(0))[3]); }

  # +------------+-----------+------+-----------+
  # | Server_id  | Host      | Port | Master_id |
  # +------------+-----------+------+-----------+
  # |  192168010 | iconnect2 | 3306 | 192168011 |
  # | 1921680101 | athena    | 3306 | 192168011 |
  # +------------+-----------+------+-----------+

  $$status_ref{'Slave_count'} = '0';

  my $sql = 'SHOW SLAVE HOSTS';
  my $sth = $dbh->prepare($sql);
  if ( $sth->execute() )
  {
    while ( my $ref = $sth->fetchrow_hashref() )
    {
      $$status_ref{'Slave_count'} += 1;
    }
    $sth->finish();
  }

  if ( $main::gParameter{'Debug'} == DBG )
  {
    &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, '    Master status:');
    foreach my $key ( keys %$status_ref )
    {
      &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, "      key: $key, value: $$status_ref{$key}");
    }
  }
}

# sql/log_event.cc
# 
# START_EVENT_V3:           Start_v3
# STOP_EVENT:               Stop
# QUERY_EVENT:              Query
# ROTATE_EVENT:             Rotate
# INTVAR_EVENT:             Intvar
# LOAD_EVENT:               Load
# NEW_LOAD_EVENT:           New_load
# SLAVE_EVENT:              Slave
# CREATE_FILE_EVENT:        Create_file
# APPEND_BLOCK_EVENT:       Append_block
# DELETE_FILE_EVENT:        Delete_file
# EXEC_LOAD_EVENT:          Exec_load
# RAND_EVENT:               RAND
# XID_EVENT:                Xid
# USER_VAR_EVENT:           User var
# FORMAT_DESCRIPTION_EVENT: Format_desc
# TABLE_MAP_EVENT:          Table_map
# PRE_GA_WRITE_ROWS_EVENT:  Write_rows_event_old
# PRE_GA_UPDATE_ROWS_EVENT: Update_rows_event_old
# PRE_GA_DELETE_ROWS_EVENT: Delete_rows_event_old
# WRITE_ROWS_EVENT:         Write_rows
# UPDATE_ROWS_EVENT:        Update_rows
# DELETE_ROWS_EVENT:        Delete_rows
# BEGIN_LOAD_QUERY_EVENT:   Begin_load_query
# EXECUTE_LOAD_QUERY_EVENT: Execute_load_query
# INCIDENT_EVENT:           Incident

sub getBinlogEvents
{
  my $dbh = shift;
  my $status_ref = shift;

  my $rc = 0;

  if ( $main::gParameter{'Debug'} >= INFO ) { &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, INFO, '    ' . (caller(0))[3]); }

  # +----------------+-----+-------------+-----------+-------------+--------------------------------------------------------------+
  # | Log_name       | Pos | Event_type  | Server_id | End_log_pos | Info                                                         |
  # +----------------+-----+-------------+-----------+-------------+--------------------------------------------------------------+
  # | bin-log.000001 |   4 | Format_desc |     35714 |         107 | Server ver: 5.1.44-ndb-7.1.4b-cluster-gpl-log, Binlog ver: 4 |
  # | bin-log.000001 | 107 | Query       |     35714 |         201 | use `test`; drop table innodb_table_monitor                  |
  # | bin-log.000001 | 201 | Query       |     35714 |         269 | BEGIN                                                        |
  # | bin-log.000001 | 269 | Table_map   |     35714 |         314 | table_id: 16 (test.t1)                                       |
  # | bin-log.000001 | 314 | Write_rows  |     35714 |         413 | table_id: 16 flags: STMT_END_F                               |
  # | bin-log.000001 | 413 | Xid         |     35714 |         440 | COMMIT /* xid=22 */                                          |
  # | bin-log.000001 | 440 | Query       |     35714 |         508 | BEGIN                                                        |
  # | bin-log.000001 | 508 | Table_map   |     35714 |         553 | table_id: 16 (test.t1)                                       |
  # | bin-log.000001 | 553 | Write_rows  |     35714 |         722 | table_id: 16 flags: STMT_END_F                               |
  # | bin-log.000001 | 722 | Xid         |     35714 |         749 | COMMIT /* xid=23 */                                          |
  # +----------------+-----+-------------+-----------+-------------+--------------------------------------------------------------+

  # Read the last position
  my $position_file = '/tmp/zabbix_agentd_master_' . $main::gParameter{'Hostname'} . '.conf';
  my $log_file = '';
  my $log_pos  = '0';
  if ( -r $position_file )
  {
    if ( $main::gParameter{'Debug'} == DBG ) {
      &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, "Using position_file for file/position.");
    }
    if ( ! open(FILE, $position_file) ) {
      $rc = 1801;
      &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, ERR, "Cannot open file $position_file (rc=$rc).\n$!\n");
      return $rc;
    }
    chomp(my @position = <FILE>);
    close(FILE);
    ($log_file, $log_pos) = split(/:/, $position[0]);

    if ( ("$log_file" eq '') || ("$log_pos" eq '') ) {
      # We have retrieved these values already earlier
      $log_pos  = $$status_ref{'Binlog_position'}; 
      $log_file = $$status_ref{'Binlog_file'};
    }
  }
  else
  {
    if ( $main::gParameter{'Debug'} == DBG ) {
      &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, "Using SHOW MASTER STATUS for file/position.");
    }
    # We have retrieved these values already earlier
    $log_pos  = $$status_ref{'Binlog_position'}; 
    $log_file = $$status_ref{'Binlog_file'};
  }

  if ( $main::gParameter{'Debug'} == DBG )
  {
    &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, "Log_file: $log_file, Log_pos: $log_pos");
  }

  $$status_ref{'Binlog_event_count'}                    = '0';
  $$status_ref{'Binlog_avg_event_size'}                 = '0';
#   $$status_ref{'Binlog_START_EVENT_count'}              = '0';
#   $$status_ref{'Binlog_STOP_EVENT_count'}               = '0';
#   $$status_ref{'Binlog_QUERY_EVENT_count'}              = '0';
#   $$status_ref{'Binlog_ROTATE_EVENT_count'}             = '0';
#   $$status_ref{'Binlog_INTVAR_EVENT_count'}             = '0';
#   $$status_ref{'Binlog_LOAD_EVENT_count'}               = '0';
#   $$status_ref{'Binlog_SLAVE_EVENT_count'}              = '0';
#   $$status_ref{'Binlog_CREATE_FILE_EVENT_count'}        = '0';
#   $$status_ref{'Binlog_APPEND_BLOCK_EVENT_count'}       = '0';
#   $$status_ref{'Binlog_DELETE_FILE_EVENT_count'}        = '0';
#   $$status_ref{'Binlog_EXEC_LOAD_EVENT_count'}          = '0';
#   $$status_ref{'Binlog_RAND_EVENT_count'}               = '0';
#   $$status_ref{'Binlog_XID_EVENT_count'}                = '0';
#   $$status_ref{'Binlog_USER_VAR_EVENT_count'}           = '0';
#   $$status_ref{'Binlog_FORMAT_DESCRIPTION_EVENT_count'} = '0';
#   $$status_ref{'Binlog_TABLE_MAP_EVENT_count'}          = '0';
#   $$status_ref{'Binlog_WRITE_ROWS_EVENT_count'}         = '0';
#   $$status_ref{'Binlog_UPDATE_ROWS_EVENT_count'}        = '0';
#   $$status_ref{'Binlog_DELETE_ROWS_EVENT_count'}        = '0';
#   $$status_ref{'Binlog_BEGIN_LOAD_QUERY_EVENT_count'}   = '0';
#   $$status_ref{'Binlog_EXECUTE_LOAD_QUERY_EVENT_count'} = '0';
#   $$status_ref{'Binlog_INCIDENT_EVENT_count'}           = '0';

  my $size = 0;
  my $last_event = '';
  my $info = '';

#   my $sql = "SHOW BINLOG EVENTS IN '$log_file' FROM $log_pos LIMIT 100000";
#   my $sth = $dbh->prepare($sql);
#   if ( $sth->execute() )
#   {
#     while ( my $ref = $sth->fetchrow_hashref() )
#     {
#       $$status_ref{'Binlog_event_count'}++;
#       $size += ($ref->{'End_log_pos'} - $ref->{'Pos'} - 1);
# 
#       if ( $ref->{'Event_type'} eq 'Start_v3' ) {
#         $$status_ref{'Binlog_START_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Stop' ) {
#         $$status_ref{'Binlog_STOP_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Query' ) {
#         $$status_ref{'Binlog_QUERY_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Rotate' ) {
#         $$status_ref{'Binlog_ROTATE_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Intvar' ) {
#         $$status_ref{'Binlog_INTVAR_EVENT_count'}++;
#       }
#       elsif ( ($ref->{'Event_type'} eq 'Load') || ($ref->{'Event_type'} eq 'New_load') ) {
#         $$status_ref{'Binlog_LOAD_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Slave' ) {
#         $$status_ref{'Binlog_SLAVE_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Create_file' ) {
#         $$status_ref{'Binlog_CREATE_FILE_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Append_block' ) {
#         $$status_ref{'Binlog_APPEND_BLOCK_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Delete_file' ) {
#         $$status_ref{'Binlog_DELETE_FILE_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Exec_load' ) {
#         $$status_ref{'Binlog_EXEC_LOAD_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'RAND' ) {
#         $$status_ref{'Binlog_RAND_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Xid' ) {
#         $$status_ref{'Binlog_XID_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'User var' ) {
#         $$status_ref{'Binlog_USER_VAR_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Format_desc' ) {
#         $$status_ref{'Binlog_FORMAT_DESCRIPTION_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Table_map' ) {
#         $$status_ref{'Binlog_TABLE_MAP_EVENT_count'}++;
#       }
#       elsif ( ($ref->{'Event_type'} eq 'Write_rows_event_old') || ($ref->{'Event_type'} eq 'Write_rows') ) {
#         $$status_ref{'Binlog_WRITE_ROWS_EVENT_count'}++;
#       }
#       elsif ( ($ref->{'Event_type'} eq 'Update_rows_event_old') || ($ref->{'Event_type'} eq 'Update_rows') ) {
#         $$status_ref{'Binlog_UPDATE_ROWS_EVENT_count'}++;
#       }
#       elsif ( ($ref->{'Event_type'} eq 'Delete_rows_event_old') || ($ref->{'Event_type'} eq 'Delete_rows') ) {
#         $$status_ref{'Binlog_DELETE_ROWS_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Begin_load_query' ) {
#         $$status_ref{'Binlog_BEGIN_LOAD_QUERY_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Execute_load_query' ) {
#         $$status_ref{'Binlog_EXECUTE_LOAD_QUERY_EVENT_count'}++;
#       }
#       elsif ( $ref->{'Event_type'} eq 'Incident' ) {
#         $$status_ref{'Binlog_INCIDENT_EVENT_count'}++;
#       }
# 
#       $last_event = $ref->{'Event_type'};
#       $info = $ref->{'Info'};
#     }
#     $sth->finish();
#   }

  if ( $$status_ref{'Binlog_event_count'} > 0 )
  {
    $$status_ref{'Binlog_avg_event_size'} = sprintf("%.1f", $size / $$status_ref{'Binlog_event_count'});
  }

  # Write the last position
  if ( $last_event eq 'Rotate' ) {
    ($log_file, $log_pos) = split(/;pos=/, $info);
  }
  elsif ( $last_event eq 'Stop' ) {
    $log_file =~ m/^.*\.(\d+)$/;
    my $nr_old = $1+0;
    my $nr_new = $1+1;
    $log_file =~ s/$nr_old/$nr_new/;
    $log_pos = 4;
  }

  if ( ! open(FILE, '>' . $position_file) ) {
    $rc = 1800;
    &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, ERR, "Cannot open file $position_file (rc=$rc).\n$!\n");
    return $rc;
  }
  print FILE join ':', $log_file, $log_pos;
  close(FILE);

  if ( $main::gParameter{'Debug'} == DBG ) {
    &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, "Writing file/position to position_file: $log_file, $log_pos");
  }

  if ( $main::gParameter{'Debug'} == DBG ) {
    &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, 'Master Status:');
    foreach my $key ( keys %$status_ref ) {
      &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, "key: $key, value: $$status_ref{$key}");
    }
  }

  return $rc;
}

sub processMasterInformation
{
  my $rc = 0;
  if ( $main::gParameter{'Debug'} >= INFO ) { &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, INFO, '    ' . (caller(0))[3]); }

  my %hMasterStatus;
  my %hGlobalVariables;

  my @aMasterStatusToSend = (
    'Binlog_avg_event_size'
  , 'Binlog_count'
  , 'Binlog_event_count'
  , 'Binlog_file'
  , 'Binlog_number'
  , 'Binlog_position'
#   , 'Binlog_APPEND_BLOCK_EVENT_count'
#   , 'Binlog_BEGIN_LOAD_QUERY_EVENT_count'
#   , 'Binlog_CREATE_FILE_EVENT_count'
#   , 'Binlog_DELETE_FILE_EVENT_count'
#   , 'Binlog_DELETE_ROWS_EVENT_count'
#   , 'Binlog_EXEC_LOAD_EVENT_count'
#   , 'Binlog_EXECUTE_LOAD_QUERY_EVENT_count'
#   , 'Binlog_FORMAT_DESCRIPTION_EVENT_count'
#   , 'Binlog_INCIDENT_EVENT_count'
#   , 'Binlog_INTVAR_EVENT_count'
#   , 'Binlog_LOAD_EVENT_count'
#   , 'Binlog_QUERY_EVENT_count'
#   , 'Binlog_RAND_EVENT_count'
#   , 'Binlog_ROTATE_EVENT_count'
#   , 'Binlog_SLAVE_EVENT_count'
#   , 'Binlog_START_EVENT_count'
#   , 'Binlog_STOP_EVENT_count'
#   , 'Binlog_TABLE_MAP_EVENT_count'
#   , 'Binlog_UPDATE_ROWS_EVENT_count'
#   , 'Binlog_USER_VAR_EVENT_count'
#   , 'Binlog_WRITE_ROWS_EVENT_count'
#   , 'Binlog_XID_EVENT_count'
  , 'Binlog_total_size'
  , 'Slave_count'
  );

  my @aGlobalVariablesToSend = (
    'auto_increment_increment'
  , 'auto_increment_offset'
  , 'binlog_row_image'
  , 'binlog_format'
  , 'binlog_cache_size'
  , 'binlog_stmt_cache_size'
  , 'expire_logs_days'
  , 'log_bin'
  , 'sync_binlog'
  , 'sync_master_info'
  );

  &FromDualMySQLagent::initValues(\%hMasterStatus, \@aMasterStatusToSend);
  &FromDualMySQLagent::initValues(\%hGlobalVariables, \@aGlobalVariablesToSend);

  # Set default values

  $hGlobalVariables{'binlog_row_image'} = 'FULL';
  $hGlobalVariables{'binlog_format'}    = 'STATEMENT';

  my $dbh = &FromDualMySQLagent::getDatabaseConnection(%main::gParameter);

  if ( ! defined($dbh) ) {
    $rc = 1802;
    if ( $main::gParameter{'Debug'} >= ERR ) { &FromDualMySQLagent::mylog($main::gParameter{'LogFile'}, DBG, "    Database connection failed (rc=$rc)."); }
    return $rc;
  }

  &getMasterStatus($dbh, \%hMasterStatus);
  &getBinaryLogs($dbh, \%hMasterStatus);
  &getSlaveCount($dbh, \%hMasterStatus);
  # Possibly overkill. No need for this!
  #&getBinlogEvents($dbh, \%hMasterStatus);

  &FromDualMySQLagent::getGlobalVariables($dbh, \%hGlobalVariables);

  &FromDualMySQLagent::releaseDatabaseConnection($dbh);

  # Do some post calculations
  if ( $hMasterStatus{'Binlog_file'} eq '' ) {
    $hMasterStatus{'Binlog_file'} = 'none';
  }

  &sendData::sendData(\%hMasterStatus, \@aMasterStatusToSend);
  &sendData::sendData(\%hGlobalVariables, \@aGlobalVariablesToSend);
  return $rc;
}

1;
__END__

